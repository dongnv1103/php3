

<?php $__env->startSection('content'); ?>

<form action="" method="get">
    <div class="row">
        <div class="col-6">
            <div class="form-group">
                <label for="">Tên tài khoản</label>
                <input class="form-control" type="text" name="keyword" <?php if(isset($searchData['keyword'])): ?> value="<?php echo e($searchData['keyword']); ?>" <?php endif; ?>>
            </div>
        </div>
        <div class="col-6">
            <div class="form-group">
                <label for="">Sắp xếp theo</label>
                <select class="form-control" name="order_by" >
                    <option value="0">Mặc định</option>
                    <option <?php if(isset($searchData['order_by']) &&  $searchData['order_by'] == 1): ?> selected <?php endif; ?>  value="1">Tên alphabet</option>
                    <option <?php if(isset($searchData['order_by']) &&  $searchData['order_by'] == 2): ?> selected <?php endif; ?> value="2">Tên giảm dần alphabet</option>
                </select>
            </div>
        </div>
        <div class="col-6">
            <button type="submit" class="btn btn-primary">Tìm kiếm</button>
        </div>
    </div>
</form><br>
<div class="row">
    <table class="table table-striped">
        <thead>
            <th>STT</th>
            <th>Tên tài khoản</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>
                <a href="#" class="btn btn-primary">Tạo mới</a>
            </th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e((($data_user->currentPage()-1)*20) + $loop->iteration); ?></td>
                <td><?php echo e($u->name); ?></td>
                <td><?php echo e($u->email); ?></td>
                <td><?php echo e($u->phone_number); ?></td>
                <td>
                    <a href="#" class="btn btn-info">Sửa</a>
                    
                    <a href="#" class="btn btn-danger">Xóa</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
        
    </table>
    <div class="d-flex justify-content-end">
        <?php echo e($data_user->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php3\dong_laravel\resources\views/admin/user/index.blade.php ENDPATH**/ ?>