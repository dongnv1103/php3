<h2>Thông tin người dùng</h2>
Họ tên: <?php echo e($name); ?>

<br>
Ngày sinh: <?php echo e($birthday); ?>

<br>
giới tính: <?php if($gender == 1): ?> Nam <?php elseif($gender == 2): ?> Nữ <?php else: ?> Khác <?php endif; ?><?php /**PATH D:\php3\dong_laravel\resources\views/user/user-info.blade.php ENDPATH**/ ?>