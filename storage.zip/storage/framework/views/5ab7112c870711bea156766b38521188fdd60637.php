

<?php $__env->startSection('content'); ?>

<form action="" method="get">
    <div class="row">
        <div class="col-6">
            <div class="form-group">
                <label for="">Tên sản phẩm</label>
                <input class="form-control" type="text" name="keyword" <?php if(isset($searchData['keyword'])): ?> value="<?php echo e($searchData['keyword']); ?>" <?php endif; ?>>
            </div>
            <div class="form-group">
                <label for="">Danh mục sản phẩm</label>
                <select class="form-control" name="cate_id" >
                    <option value="">Tất cả</option>
                    <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if(isset($searchData['cate_id']) && $c->id == $searchData['cate_id']): ?> selected <?php endif; ?> value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-6">
            <div class="form-group">
                <label for="">Sắp xếp theo</label>
                <select class="form-control" name="order_by" >
                    <option value="0">Mặc định</option>
                    <option <?php if(isset($searchData['order_by']) &&  $searchData['order_by'] == 1): ?> selected <?php endif; ?>  value="1">Tên alphabet</option>
                    <option <?php if(isset($searchData['order_by']) &&  $searchData['order_by'] == 2): ?> selected <?php endif; ?> value="2">Tên giảm dần alphabet</option>
                    <option <?php if(isset($searchData['order_by']) &&  $searchData['order_by'] == 3): ?> selected <?php endif; ?> value="3">Giá tăng dần</option>
                    <option <?php if(isset($searchData['order_by']) &&  $searchData['order_by'] == 4): ?> selected <?php endif; ?> value="4">Giá giảm dần</option>
                </select>
            </div>
            <div class="text-center">
                <br>
                <button type="submit" class="btn btn-primary">Tìm kiếm</button>
            </div>
        </div>
    </div>
</form>
<div class="row">
    <table class="table table-striped">
        <thead>
            <th>STT</th>
            <th>Tên SP</th>
            <th>Ảnh</th>
            <th>Danh mục</th>
            <th>Giá</th>
            <th>Số lượng</th>
            <th>
                <a href="<?php echo e(route('product.add')); ?>" class="btn btn-primary">Tạo mới</a>
            </th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e((($data_product->currentPage()-1)*20) + $loop->iteration); ?></td>
                <td><?php echo e($p->name); ?></td>
                <td><img src="<?php echo e(asset( 'storage/' . $p->image)); ?>" width="70" /></td>
                <td>
                    <a href="<?php echo e(route('category.detail', ['id' => $p->cate_id])); ?>"><?php echo e($p->category->name); ?></a>
                </td>
                <td><?php echo e($p->price); ?></td>
                <td><?php echo e($p->quantity); ?></td>
                <td>
                    <a href="<?php echo e(route('product.edit', ['id' => $p->id])); ?>" class="btn btn-info">Sửa</a>
                    <a href="<?php echo e(route('product.remove', ['id' => $p->id])); ?>" class="btn btn-danger">Xóa</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
        
    </table>
    <div class="d-flex justify-content-end">
        <?php echo e($data_product->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php3\dong_laravel\resources\views/admin/products/index.blade.php ENDPATH**/ ?>