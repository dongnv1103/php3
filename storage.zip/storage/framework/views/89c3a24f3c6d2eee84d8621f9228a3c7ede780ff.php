<table>
    <thead>
        <th>ID</th>
        <th>Name</th>
        <th>
            <a href="">Tạo mới</a>
        </th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($c->id); ?></td>
                <td><?php echo e($c->name); ?></td>
                <td>
                    <a href="<?php echo e(route('cate.remove', ['id' => $c -> id])); ?>">Xóa</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\php3\dong_laravel\resources\views/home/index.blade.php ENDPATH**/ ?>