

<?php $__env->startSection('content'); ?>

<form action="" method="get">
    <div class="row">
        <div class="col-6">
            <div class="form-group">
                <label for="">Tên phòng</label>
                <input class="form-control" type="text" name="keyword" <?php if(isset($searchData['keyword'])): ?> value="<?php echo e($searchData['keyword']); ?>" <?php endif; ?>>
            </div>
        </div>
        <div class="col-6">
            <div class="form-group">
                <label for="">Sắp xếp theo</label>
                <select class="form-control" name="order_by" >
                    <option value="0">Mặc định</option>
                    <option <?php if(isset($searchData['order_by']) &&  $searchData['order_by'] == 1): ?> selected <?php endif; ?>  value="1">Tên alphabet</option>
                    <option <?php if(isset($searchData['order_by']) &&  $searchData['order_by'] == 2): ?> selected <?php endif; ?> value="2">Tên giảm dần alphabet</option>
                    <option <?php if(isset($searchData['order_by']) &&  $searchData['order_by'] == 3): ?> selected <?php endif; ?> value="3">Giá tăng dần</option>
                    <option <?php if(isset($searchData['order_by']) &&  $searchData['order_by'] == 4): ?> selected <?php endif; ?> value="4">Giá giảm dần</option>
                </select>
            </div>
        </div>
        <div class="col-6">
            <button type="submit" class="btn btn-primary">Tìm kiếm</button>
        </div>
    </div>
</form><br>
<div class="row">
    <table class="table table-striped">
        <thead>
            <th>STT</th>
            <th>Room_no</th>
            <th>Image</th>
            <th>Floor</th>
            <th>Price</th>
            <th>
                <a href="<?php echo e(route('room.add')); ?>" class="btn btn-primary">Tạo mới</a>
            </th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data_room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e((($data_room->currentPage()-1)*20) + $loop->iteration); ?></td>
                <td><?php echo e($r->room_no); ?></td>
                <td><img src="<?php echo e(asset( 'storage/' . $r->image)); ?>" width="70" /></td>
                <td><?php echo e($r->floor); ?></td>
                <td><?php echo e($r->price); ?></td>
                <td>
                    <a href="<?php echo e(route('room.edit', ['id' => $r->id])); ?>" class="btn btn-info">Sửa</a>
                    <a href="<?php echo e(route('room.remove', ['id' => $r->id])); ?>" class="btn btn-danger">Xóa</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
        
    </table>
    <div class="d-flex justify-content-end">
        <?php echo e($data_room->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php3\dong_laravel\resources\views/admin/rooms/index.blade.php ENDPATH**/ ?>