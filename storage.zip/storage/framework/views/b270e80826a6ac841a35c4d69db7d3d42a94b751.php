

<?php $__env->startSection('content'); ?>

<form action="" method="get">
    <div>
        <label for="">Tên danh mục</label>
        <input type="text" name="keyword" <?php if(isset($searchData['keyword'])): ?> value="<?php echo e($searchData['keyword']); ?>" <?php endif; ?>>
    </div>
    <div>
        <label for="">Sắp xếp theo</label>
        <select name="order_by" >
            <option value="0">Mặc định</option>
            <option <?php if(isset($searchData['order_by']) &&  $searchData['order_by'] == 1): ?> selected <?php endif; ?>  value="1">Tên alphabet</option>
            <option <?php if(isset($searchData['order_by']) &&  $searchData['order_by'] == 2): ?> selected <?php endif; ?> value="2">Tên giảm dần alphabet</option>
            <option <?php if(isset($searchData['order_by']) &&  $searchData['order_by'] == 3): ?> selected <?php endif; ?> value="3">Giá tăng dần</option>
            <option <?php if(isset($searchData['order_by']) &&  $searchData['order_by'] == 4): ?> selected <?php endif; ?> value="4">Giá giảm dần</option>
        </select>
    </div>
    <div>
        <button type="submit">Tìm kiếm</button>
    </div>
</form>

<table>
    <thead>
        <th>STT</th>
        <th>Tên danh mục</th>
        <th>
            <a href="#">Tạo mới</a>
        </th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data_cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e((($data_cate->currentPage()-1)*20) + $loop->iteration); ?></td>
            <td><?php echo e($c->name); ?></td>
            <td>
                <button>Sửa</button>
                <button>Xóa</button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>
    
</table>
<?php echo e($data_cate->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php3\dong_laravel\resources\views/admin/category/index.blade.php ENDPATH**/ ?>