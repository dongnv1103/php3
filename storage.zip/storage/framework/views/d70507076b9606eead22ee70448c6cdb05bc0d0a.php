<table>
    <thead>
        <th>ID</th>
        <th>Name</th>
        <th>Image</th>
        <th>Price</th>
        <th>Quantity</th>
        <th>
            <a href="products/them">Tạo mới</a>
        </th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($p->id); ?></td>
                <td><?php echo e($p->name); ?></td>
                <td><?php echo e($p->image); ?></td>
                <td><?php echo e($p->price); ?></td>
                <td><?php echo e($p->quantity); ?></td>
                <td>
                    <a href="">Xóa</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div>
    <form action="">
        <div>
            <label for="">Danh mục</label>
            <input type="text" name="category">
        </div>
    
        <div>
            <label for="">Tên</label>
            <input type="text" name="name">
        </div>
    
        <div>
            <label for="">Giá</label>
            <input type="text" name="price">
        </div>
    
        <div>
            <label for="">Sắp xếp theo</label>
            <select name="sx" id="">
                <option value="1">Giá tăng dần</option>
                <option value="2">Giá giảm dần</option>
                <option value="3">Trạng thái active</option>
                <option value="4">Số lượng giảm dần</option>
                <option value="5">Số lượng tăng dần</option>
            </select>
        </div>
        
    </form>
</div><?php /**PATH D:\php3\dong_laravel\resources\views/home/product.blade.php ENDPATH**/ ?>