<h2>Thông tin danh mục</h2>
<p>Tên danh mục: <?php echo e($cate->name); ?></p>
<p>Số lượng sản phẩm: <?php echo e(count($cate->products)); ?></p>
<ul>
    <?php $__currentLoopData = $cate->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($p->name); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH D:\php3\dong_laravel\resources\views/admin/category/detail.blade.php ENDPATH**/ ?>